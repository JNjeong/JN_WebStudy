public class day08_myMath {
    int add(int a, int b){
        // int result = a+b;
        // return result;
        return a+b;
    }

    int sub(int a , int b){
        return a-b;
    }
}
