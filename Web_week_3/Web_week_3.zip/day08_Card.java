public class day08_Card {
    String kind;    //객체 변수
    int number;     //객체 변수
    static int width = 100; //클래스 변수
    static int height = 250; //클래스 변수


}
